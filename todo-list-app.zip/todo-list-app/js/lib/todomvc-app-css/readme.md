# todomvc-app-css

> CSS for TodoMVC apps

![](screenshot.png)


## Install


```
$ npm install todomvc-app-css
```


## Getting started

```html
<link rel="stylesheet" href="node_modules/todomvc-app-css/index.css">
```

See the [TodoMVC app template](https://github.com/tastejs/todomvc-app-template).


## License

CC-BY-4.0 © [Sindre Sorhus](https://sindresorhus.com)
